import pygame, sys, random
from pygame.locals import *
from pygame import mixer

pygame.init()

#music
pygame.mixer.init()
my_sound = pygame.mixer.Sound('ressources/music.mp3')
my_sound.play()
my_sound.set_volume(0.25)

#Display
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
DISPLAY = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))

#caption
pygame.display.set_caption("Alien Invasion")

#icon
icon = pygame.image.load("ressources/icon.png")
pygame.display.set_icon(icon)

#constants
SHIP_WIDTH, SHIP_HEIGHT = 50,50
VEL = 4
ENEMY_VEL = 1.75
BULLET_VEL = 6
MAX_BULLETS = 1

#Score
score = 0
pygame.font.init()
font = pygame.font.SysFont("arial",20)
lost = False

#colors
WHITE = pygame.Color(255, 255, 255)   # White
RED = pygame.Color(255,0,0) #red

#backround
backround = pygame.image.load("ressources/backround.jpg")

#player ship
player_ship = pygame.image.load("ressources/Player.png")

#Enemy ship
enemy_ship = pygame.image.load("ressources/Enemy.png")

#draw function
def display_draw(player, bullets):
    global lost
    DISPLAY.blit(backround,(0,0))
    DISPLAY.blit(player_ship,(player.x,player.y))  
    DISPLAY.blit(enemy_ship,(enemy.x,enemy.y))
    DISPLAY.blit(enemy_ship,(enemy2.x,enemy2.y))
    DISPLAY.blit(enemy_ship,(enemy3.x,enemy3.y))
    score_text = font.render("Score: " + str(score), 1 ,WHITE)
    DISPLAY.blit(score_text, (0,0))

    if lost == True:
        lose_text = font.render("You lost!",1,WHITE)
        DISPLAY.blit(lose_text,(0,20))

    for bullet in bullets:
        pygame.draw.rect(DISPLAY, RED, bullet)

    pygame.display.update()


enemy_width = random.randint(1,347)
enemy_width2 = random.randint(1,347)
enemy_width3 = random.randint(1,347)

enemy_height = random.randint(-300,10)
enemy_height2 = random.randint(-300,10)
enemy_height3 = random.randint(-300,10)

enemy = pygame.Rect(enemy_width,enemy_height,SHIP_WIDTH,SHIP_HEIGHT)
enemy2 = pygame.Rect(enemy_width2,enemy_height2,SHIP_WIDTH,SHIP_HEIGHT)
enemy3 = pygame.Rect(enemy_width3,enemy_height3,SHIP_WIDTH,SHIP_HEIGHT)
player = pygame.Rect(SCREEN_WIDTH/2 - SHIP_WIDTH/2,450,SHIP_WIDTH,SHIP_HEIGHT)

bullets =[]

def handle_bullets(bullets, player, enemy, enemy2, enemy3):

    for bullet in bullets:
        global score
        bullet.y -= BULLET_VEL
        if enemy.colliderect(bullet):
            enemy.y = -100
            enemy.x = random.randint(0,350)
            bullets.remove(bullet)
            score = score + 1

        if enemy2.colliderect(bullet):
            enemy2.y = -100
            enemy2.x = random.randint(0,350)
            bullets.remove(bullet)
            score = score + 1

        if enemy3.colliderect(bullet):
            enemy3.y = -100
            enemy3.x = random.randint(0,350)
            bullets.remove(bullet)
            score = score + 1

        elif bullet.y < 0:
            bullets.remove(bullet)
        
        return score

def lose():
    global lost
    lost = True
    my_sound.stop()
    enemy.y = 1000
    enemy2.y = 1000
    enemy3.y = 1000

running = True
while running:

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    FPS = pygame.time.Clock()
    FPS.tick(60)

    #print(enemy.y)
    #print(BULLET_HIT)
    
    keys_pressed = pygame.key.get_pressed()
    if keys_pressed[pygame.K_LEFT] and player.x - VEL > 0:  #left
        player.x -= VEL
    if keys_pressed[pygame.K_RIGHT] and player.x - VEL +53 < 400:  #right
        player.x += VEL

    enemy.y += ENEMY_VEL
    if enemy.y > 480:
        lose()

    enemy2.y += ENEMY_VEL
    if enemy2.y > 480:
        lose()

    enemy3.y += ENEMY_VEL
    if enemy3.y > 480:
        lose()
        
    if event.type == pygame.KEYUP:
        if event.key == pygame.K_LCTRL and len(bullets) < MAX_BULLETS:
            bullet = pygame.Rect(player.x + SHIP_WIDTH / 2, player.y + SHIP_HEIGHT/2,5,10)
            bullets.append(bullet)

    handle_bullets(bullets, player, enemy, enemy2, enemy3)
    
    display_draw(player, bullets)
    pygame.display.update()

    
